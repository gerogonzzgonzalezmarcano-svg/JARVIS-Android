package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var orb: OrbView
    private var tts: TextToSpeech? = null
    private var speech: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var listening = false
    private var speaking = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.rgb(3, 9, 20)
        window.navigationBarColor = Color.rgb(3, 9, 20)
        tts = TextToSpeech(this, this)
        buildInterface()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41)
        } else startListeningSoon(900)
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            setPadding(28, 20, 28, 24)
            setBackgroundColor(Color.rgb(3, 9, 20))
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S."; textSize = 27f; letterSpacing = 0.22f
            setTextColor(Color.rgb(92, 224, 255)); gravity = android.view.Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "SISTEMA PESSOAL • ONLINE"; textSize = 10f; letterSpacing = 0.2f
            setTextColor(Color.rgb(80, 132, 165)); gravity = android.view.Gravity.CENTER
        }
        orb = OrbView()
        status = TextView(this).apply {
            text = "INICIALIZANDO SISTEMAS"; textSize = 13f; letterSpacing = 0.12f
            setTextColor(Color.rgb(88, 218, 255)); gravity = android.view.Gravity.CENTER
        }
        transcript = TextView(this).apply {
            text = "Diga ‘Jarvis’ para começar"; textSize = 17f
            setTextColor(Color.WHITE); gravity = android.view.Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 54))
        root.addView(subtitle, LinearLayout.LayoutParams(-1, 28))
        root.addView(orb, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(status, LinearLayout.LayoutParams(-1, 42))
        root.addView(transcript, LinearLayout.LayoutParams(-1, 74))
        setContentView(root)
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            val chosen = tts?.setLanguage(Locale("pt", "BR"))
            tts?.setSpeechRate(0.91f)
            if (chosen == TextToSpeech.LANG_MISSING_DATA || chosen == TextToSpeech.LANG_NOT_SUPPORTED) {
                status.text = "VOZ DO SISTEMA INDISPONÍVEL"
            } else {
                // Sound signature made from original tones, not the copyrighted film theme.
                playStartupSignature()
                handler.postDelayed({ speak("Sistemas iniciados. Estou aqui. Pode falar.") }, 1100)
            }
        }
    }

    private fun playStartupSignature() {
        // Short, original synthesized sci-fi startup sequence using the device tone generator.
        val gen = android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 55)
        val tones = intArrayOf(android.media.ToneGenerator.TONE_DTMF_1, android.media.ToneGenerator.TONE_DTMF_4,
            android.media.ToneGenerator.TONE_DTMF_7, android.media.ToneGenerator.TONE_DTMF_3)
        tones.forEachIndexed { i, tone -> handler.postDelayed({ try { gen.startTone(tone, 105) } catch (_: Exception) {} }, i * 145L) }
        handler.postDelayed({ try { gen.release() } catch (_: Exception) {} }, 900)
    }

    private fun speak(text: String) {
        speaking = true; listening = false
        status.text = "J.A.R.V.I.S. FALANDO"
        transcript.text = text
        orb.invalidate()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-${System.currentTimeMillis()}")
        handler.postDelayed({ speaking = false; orb.invalidate(); startListeningSoon(500) }, (text.length * 58L).coerceIn(1300L, 6500L))
    }

    private fun startListeningSoon(delay: Long) {
        handler.postDelayed({ startListening() }, delay)
    }

    private fun startListening() {
        if (isFinishing || speaking || checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "RECONHECIMENTO DE VOZ INDISPONÍVEL"
            transcript.text = "Verifique os serviços de voz do Android."
            return
        }
        try {
            speech?.destroy()
            speech = SpeechRecognizer.createSpeechRecognizer(this)
            speech?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { listening = true; status.text = "OUVINDO • DIGA ‘JARVIS’"; orb.invalidate() }
                override fun onBeginningOfSpeech() { status.text = "OUVINDO COM ATENÇÃO" }
                override fun onRmsChanged(rmsdB: Float) { orb.level = rmsdB; orb.invalidate() }
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { listening = false; status.text = "PROCESSANDO"; orb.invalidate() }
                override fun onError(error: Int) { listening = false; orb.invalidate(); startListeningSoon(700) }
                override fun onResults(results: Bundle?) {
                    listening = false
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (words.isNotBlank()) handleCommand(words)
                    else startListeningSoon(400)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            speech?.startListening(intent)
        } catch (_: Exception) { startListeningSoon(1000) }
    }

    private fun handleCommand(raw: String) {
        val command = raw.lowercase(Locale("pt", "BR")).trim()
        transcript.text = "Você: $raw"
        if (!command.contains("jarvis") && !listening) {
            startListeningSoon(250); return
        }
        when {
            command.contains("jarvis") && (command.length < 13 || command == "jarvis") -> speak("Estou aqui. Pode falar.")
            command.contains("youtube") -> openApp("com.google.android.youtube", "Abrindo o YouTube.")
            command.contains("whatsapp") -> openApp("com.whatsapp", "Abrindo o WhatsApp.")
            command.contains("free fire") || command.contains("freefire") -> openApp("com.dts.freefireth", "Abrindo o Free Fire, se estiver instalado.")
            command.contains("configura") -> { speak("Abrindo as configurações do dispositivo."); handler.postDelayed({ try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) } catch (_: Exception) {} }, 900) }
            command.contains("câmera") || command.contains("camera") -> { speak("Abrindo a câmera."); handler.postDelayed({ try { startActivity(Intent("android.media.action.IMAGE_CAPTURE")) } catch (_: Exception) {} }, 900) }
            command.contains("hora") -> speak("Agora são ${java.text.SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(java.util.Date())}.")
            command.contains("volume") -> speak("Por enquanto, o ajuste de volume precisa ser feito pelos controles do Android.")
            command.contains("parar") || command.contains("encerra") || command.contains("silêncio") -> { listening = false; status.text = "EM ESPERA"; speak("Entendido. Vou entrar em espera.") }
            else -> speak("Entendi. Ainda estou aprendendo esse comando. Posso abrir YouTube, WhatsApp, câmera, configurações ou Free Fire.")
        }
    }

    private fun openApp(packageName: String, message: String) {
        speak(message)
        handler.postDelayed({
            try {
                val launch = packageManager.getLaunchIntentForPackage(packageName)
                if (launch != null) startActivity(launch) else Toast.makeText(this, "Esse aplicativo não foi encontrado.", Toast.LENGTH_SHORT).show()
            } catch (_: Exception) { Toast.makeText(this, "Não foi possível abrir o aplicativo.", Toast.LENGTH_SHORT).show() }
        }, 900)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startListeningSoon(700)
        else { status.text = "MICROFONE DESATIVADO"; transcript.text = "Autorize o microfone nas permissões do app." }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        speech?.destroy(); tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }

    inner class OrbView : View(this@MainActivity) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        var level = 0f
        private var phase = 0f
        private val tick = object : Runnable { override fun run() { phase += 0.055f; invalidate(); handler.postDelayed(this, 45) } }
        init { tick.run() }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f; val cy = height / 2f; val radius = minOf(width, height) * 0.31f
            paint.style = Paint.Style.STROKE
            for (i in 0..5) {
                paint.strokeWidth = if (i == 0) 3f else 1.1f
                paint.color = Color.argb((90 - i * 10).coerceAtLeast(25), 44, 204, 255)
                val r = radius * (0.48f + i * 0.13f) + if (listening) (sin(phase * 2 + i) * 3f + level.coerceIn(0f, 10f)) else sin(phase + i) * 2f
                canvas.drawCircle(cx, cy, r, paint)
            }
            paint.strokeWidth = 2f; paint.color = Color.rgb(70, 220, 255)
            for (i in 0 until 48) {
                val a = i * Math.PI / 24 + phase * (if (speaking) 1.8 else 0.45)
                val inner = radius * 0.83f
                val outer = inner + if (i % 4 == 0) 16f else 6f
                canvas.drawLine(cx + cos(a).toFloat() * inner, cy + sin(a).toFloat() * inner,
                    cx + cos(a).toFloat() * outer, cy + sin(a).toFloat() * outer, paint)
            }
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(28, 42, 190, 255); canvas.drawCircle(cx, cy, radius * 0.63f, paint)
            paint.color = Color.rgb(117, 235, 255); paint.textAlign = Paint.Align.CENTER; paint.textSize = 20f; paint.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            canvas.drawText("J", cx, cy + 7f, paint)
        }
    }
}
