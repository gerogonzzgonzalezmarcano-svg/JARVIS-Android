# J.A.R.V.I.S. — protótipo Android nativo

Projeto inicial para Android Studio, pensado para o Samsung Galaxy A52 5G.

## O que esta versão faz
- Interface futurista azul/preta com núcleo animado.
- Solicita permissão do microfone e tenta reconhecer fala em português brasileiro enquanto o app está aberto.
- Responde por síntese de voz do Android.
- Comandos experimentais para abrir YouTube, WhatsApp, câmera, configurações e Free Fire (se instalado), além de informar a hora.
- Toca ao iniciar uma assinatura curta de tons futuristas originais. Não é a música do filme Homem de Ferro; a trilha original é protegida por direitos autorais.

## Limitações importantes
Esta é uma primeira versão de protótipo, não o produto completo descrito na especificação. A ativação contínua por palavra-chave não está implementada como detecção local confiável: o reconhecimento depende dos serviços de fala do Android e pode interromper ou reiniciar. Não funciona garantidamente com tela bloqueada/em segundo plano. Não inclui IA online, busca web, memória persistente, câmera com análise de imagem, gestos ou controle irrestrito do sistema.

## Gerar APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `JARVIS` como projeto existente.
3. Aguarde o Gradle sincronizar e instale os componentes Android SDK pedidos.
4. Use **Build > Build APK(s)**.
5. O APK de debug normalmente ficará em `app/build/outputs/apk/debug/app-debug.apk`.

Requisitos: Android Studio recente, JDK compatível e Android SDK 35. O projeto ainda precisa ser compilado e testado no aparelho real.

## Compilar sem computador (usando GitHub Actions)
Este ZIP inclui `.github/workflows/build-apk.yml` para compilar o APK em um runner online do GitHub. Não gera um APK sozinho: é preciso enviar o projeto para um repositório GitHub e executar a ação `Build JARVIS APK`. Quando terminar, abra a execução em **Actions**, baixe o artefato `JARVIS-debug-APK` e extraia `app-debug.apk` no celular. O GitHub pode exigir conta e autenticação.

Observação: o APK de debug serve para testes. A ativação por palavra-chave contínua e a execução confiável com a tela apagada ainda não estão implementadas.
